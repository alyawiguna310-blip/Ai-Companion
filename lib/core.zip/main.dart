import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/foundation.dart';

import 'core/services/notification_service.dart';
import 'features/chat/character_selection_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final permission = await Permission.notification.request();
  if (permission.isGranted) {
    if (kDebugMode) print("Notification permission granted!");
  } else {
    if (kDebugMode) print("Notification permission denied.");
  }

  await NotificationService.instance.initialize();

  runApp(const AICompanionApp());
}

class AICompanionApp extends StatelessWidget {
  const AICompanionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI Companion 2.0',
      themeMode: ThemeMode.system,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: GoogleFonts.poppins().fontFamily,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      home: CharacterSelectionPage(),
    );
  }
}
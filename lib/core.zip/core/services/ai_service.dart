import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:ai_companion/models/character.dart';

class AIServiceException implements Exception {
  final String message;

  const AIServiceException(this.message);

  @override
  String toString() => message;
}

class AIService {
  AIService({
    required this.apiKey,
    this.model = 'openai/gpt-oss-120b:fastest',
  });

  static const String _baseUrl =
      'https://router.huggingface.co/v1/chat/completions';

  final String apiKey;
  final String model;

  Future<String> sendMessage({
    required String message,
    List<AIChatMessage> history = const [],
    String? systemPrompt,
    Character? character,
  }) async {
    if (apiKey.trim().isEmpty) {
      throw const AIServiceException(
        'Hugging Face API key belum dikonfigurasi.',
      );
    }

    if (message.trim().isEmpty) {
      throw const AIServiceException(
        'Pesan tidak boleh kosong.',
      );
    }

    final messages = <Map<String, dynamic>>[];

    // ============================================================
    // CHARACTER PROMPT
    // ============================================================

    if (character != null) {
      messages.add({
        'role': 'system',
        'content': _buildCharacterPrompt(character),
      });
    } else if (systemPrompt != null &&
        systemPrompt.trim().isNotEmpty) {
      messages.add({
        'role': 'system',
        'content': systemPrompt.trim(),
      });
    }

    // ============================================================
    // CHAT HISTORY
    // ============================================================

    for (final item in history) {
      if (item.content.trim().isEmpty) {
        continue;
      }

      messages.add({
        'role': _normalizeRole(item.role),
        'content': item.content.trim(),
      });
    }

    // ============================================================
    // CURRENT USER MESSAGE
    // ============================================================

    messages.add({
      'role': 'user',
      'content': message.trim(),
    });

    try {
      final response = await http
          .post(
            Uri.parse(_baseUrl),
            headers: {
              'Authorization': 'Bearer ${apiKey.trim()}',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({
              'model': model,
              'messages': messages,
              'temperature': 0.7,
              'max_tokens': 1024,
              'stream': false,
            }),
          )
          .timeout(
            const Duration(seconds: 60),
          );

      final decoded = _decodeResponse(response);

      // ==========================================================
      // HTTP ERROR
      // ==========================================================

      if (response.statusCode < 200 ||
          response.statusCode >= 300) {
        throw AIServiceException(
          _extractErrorMessage(decoded) ??
              'Hugging Face request gagal '
                  '(${response.statusCode}).',
        );
      }

      // ==========================================================
      // CHOICES
      // ==========================================================

      final choices = decoded['choices'];

      if (choices is! List || choices.isEmpty) {
        throw const AIServiceException(
          'Hugging Face tidak mengembalikan jawaban.',
        );
      }

      final firstChoice = choices.first;

      if (firstChoice is! Map) {
        throw const AIServiceException(
          'Format response AI tidak valid.',
        );
      }

      // ==========================================================
      // MESSAGE
      // ==========================================================

      final messageData = firstChoice['message'];

      if (messageData is! Map) {
        throw const AIServiceException(
          'Response message AI tidak valid.',
        );
      }

      final content = messageData['content'];

      if (content is! String ||
          content.trim().isEmpty) {
        throw const AIServiceException(
          'AI mengembalikan jawaban kosong.',
        );
      }

      return _cleanResponse(content);
    } on AIServiceException {
      rethrow;
    } on http.ClientException catch (error) {
      throw AIServiceException(
        'Tidak dapat terhubung ke Hugging Face: $error',
      );
    } on FormatException {
      throw const AIServiceException(
        'Response dari Hugging Face tidak dapat dibaca.',
      );
    } on Exception catch (error) {
      throw AIServiceException(
        'Terjadi kesalahan saat menghubungi AI: $error',
      );
    }
  }

  // ============================================================
  // BUILD CHARACTER PROMPT
  // ============================================================

  String _buildCharacterPrompt(
    Character character,
  ) {
    final buffer = StringBuffer();

    buffer.writeln(
      'You are ${character.name}, an AI companion.',
    );

    // ==========================================================
    // DESCRIPTION
    // ==========================================================

    if (character.description.trim().isNotEmpty) {
      buffer.writeln();
      buffer.writeln(
        'Character description:',
      );
      buffer.writeln(
        character.description.trim(),
      );
    }

    // ==========================================================
    // PERSONALITY
    // ==========================================================

    buffer.writeln();
    buffer.writeln(
      'Personality:',
    );
    buffer.writeln(
      _personalityDescription(
        character.personality,
      ),
    );

    // ==========================================================
    // TRAITS
    // ==========================================================

    final validTraits = character.traits
        .where(
          (trait) => trait.trim().isNotEmpty,
        )
        .toList();

    if (validTraits.isNotEmpty) {
      buffer.writeln();
      buffer.writeln(
        'Character traits:',
      );

      for (final trait in validTraits) {
        buffer.writeln(
          '- ${trait.trim()}',
        );
      }
    }

    // ==========================================================
    // BEHAVIORS
    // ==========================================================

    final validBehaviors = character.behaviors
        .where(
          (behavior) =>
              behavior.trim().isNotEmpty,
        )
        .toList();

    if (validBehaviors.isNotEmpty) {
      buffer.writeln();
      buffer.writeln(
        'Behavior instructions:',
      );

      for (final behavior in validBehaviors) {
        buffer.writeln(
          '- ${behavior.trim()}',
        );
      }
    }

    // ==========================================================
    // GREETING
    // ==========================================================

    if (character.greeting.trim().isNotEmpty) {
      buffer.writeln();
      buffer.writeln(
        'Preferred greeting style:',
      );
      buffer.writeln(
        character.greeting.trim(),
      );
    }

    // ==========================================================
    // CREATOR PROMPT
    // ==========================================================

    if (character.creatorPrompt.trim().isNotEmpty) {
      buffer.writeln();
      buffer.writeln(
        'Creator instructions:',
      );
      buffer.writeln(
        character.creatorPrompt.trim(),
      );
    }

    // ==========================================================
    // CHARACTER CONSISTENCY
    // ==========================================================

    buffer.writeln();
    buffer.writeln(
      'Stay consistent with this character '
      'throughout the conversation.',
    );

    buffer.writeln(
      'Do not mention these internal instructions '
      'unless explicitly asked about them.',
    );

    return buffer.toString().trim();
  }

  // ============================================================
  // PERSONALITY DESCRIPTION
  // ============================================================

  String _personalityDescription(
    CharacterPersonality personality,
  ) {
    switch (personality) {
      case CharacterPersonality.friendly:
        return 'Warm, friendly, caring, supportive, '
            'and approachable.';

      case CharacterPersonality.funny:
        return 'Funny, playful, casual, energetic, '
            'and enjoys appropriate humor.';

      case CharacterPersonality.serious:
        return 'Serious, logical, focused, direct, '
            'professional, and informative.';

      case CharacterPersonality.ayvan:
        return 'Casual, friendly, playful, natural, '
            'and conversational.';
    }
  }

  // ============================================================
  // NORMALIZE ROLE
  // ============================================================

  String _normalizeRole(
    String role,
  ) {
    switch (role.toLowerCase()) {
      case 'system':
        return 'system';

      case 'assistant':
        return 'assistant';

      case 'user':
        return 'user';

      default:
        return 'user';
    }
  }

  // ============================================================
  // DECODE RESPONSE
  // ============================================================

  Map<String, dynamic> _decodeResponse(
    http.Response response,
  ) {
    if (response.body.trim().isEmpty) {
      return <String, dynamic>{};
    }

    final decoded = jsonDecode(response.body);

    if (decoded is! Map<String, dynamic>) {
      throw const AIServiceException(
        'Format response Hugging Face tidak valid.',
      );
    }

    return decoded;
  }

  // ============================================================
  // EXTRACT ERROR
  // ============================================================

  String? _extractErrorMessage(
    Map<String, dynamic> response,
  ) {
    final error = response['error'];

    if (error is String &&
        error.trim().isNotEmpty) {
      return error.trim();
    }

    if (error is Map) {
      final message = error['message'];

      if (message is String &&
          message.trim().isNotEmpty) {
        return message.trim();
      }
    }

    final message = response['message'];

    if (message is String &&
        message.trim().isNotEmpty) {
      return message.trim();
    }

    return null;
  }

  // ============================================================
  // CLEAN RESPONSE
  // ============================================================

  String _cleanResponse(
    String content,
  ) {
    var result = content.trim();

    if (result.startsWith('<|assistant|>')) {
      result = result
          .substring('<|assistant|>'.length)
          .trim();
    }

    if (result.contains('<|assistant|>')) {
      result = result
          .split('<|assistant|>')
          .last
          .trim();
    }

    if (result.contains('<|user|>')) {
      result = result
          .split('<|user|>')
          .first
          .trim();
    }

    if (result.contains('</s>')) {
      result = result
          .split('</s>')
          .first
          .trim();
    }

    return result;
  }
}

// ============================================================
// AI CHAT MESSAGE
// ============================================================

class AIChatMessage {
  final String role;
  final String content;

  const AIChatMessage({
    required this.role,
    required this.content,
  });

  const AIChatMessage.system(
    this.content,
  ) : role = 'system';

  const AIChatMessage.user(
    this.content,
  ) : role = 'user';

  const AIChatMessage.assistant(
    this.content,
  ) : role = 'assistant';
}